import os, re, json, shutil, subprocess, tempfile
from pathlib import Path
import streamlit as st
import yt_dlp
from faster_whisper import WhisperModel

st.set_page_config(page_title="Viral Clip Maker", page_icon="🎬", layout="centered")
st.title("🎬 Viral Clip Maker")
st.write("ভিডিও লিংক দিন—অ্যাপটি কথাবার্তা বিশ্লেষণ করে সম্ভাব্য আকর্ষণীয় ছোট ক্লিপ তৈরি করবে।")

st.info("YouTube ও yt-dlp সমর্থিত কিছু পাবলিক লিংক কাজ করতে পারে। প্রাইভেট, DRM-সুরক্ষিত, লগইন-প্রয়োজনীয় বা নিষিদ্ধ ভিডিও কাজ নাও করতে পারে। নিজের/অনুমতিপ্রাপ্ত ভিডিও ব্যবহার করুন।")

url = st.text_input("ভিডিও লিংক", placeholder="https://www.youtube.com/watch?v=...")
clip_len = st.slider("প্রতিটি ক্লিপের দৈর্ঘ্য (সেকেন্ড)", 20, 90, 45)
num_clips = st.slider("কতটি ক্লিপ বানাবেন?", 1, 8, 3)
vertical = st.checkbox("মোবাইলের জন্য 9:16 ভার্টিক্যাল ভিডিও বানান", value=True)
model_size = st.selectbox("ট্রান্সক্রিপশন মডেল", ["tiny", "base", "small"], index=0,
                          help="tiny দ্রুত চলে; small তুলনামূলক ভালো ফল দেয়, তবে বেশি RAM লাগে।")

def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stderr[-2500:] or "কমান্ড চালানো যায়নি।")
    return p

def download_video(url, folder):
    out = str(Path(folder) / "source.%(ext)s")
    opts = {
        "outtmpl": out, "format": "best[height<=1080]/best",
        "merge_output_format": "mp4", "noplaylist": True,
        "quiet": True, "no_warnings": True,
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        downloaded = Path(ydl.prepare_filename(info))
    if not downloaded.exists():
        candidates = list(Path(folder).glob("source.*"))
        if not candidates:
            raise RuntimeError("ভিডিও ফাইল পাওয়া যায়নি।")
        downloaded = candidates[0]
    return downloaded, info.get("title", "video")

def transcribe(video, model_size):
    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(str(video), vad_filter=True)
    rows = []
    for s in segments:
        txt = s.text.strip()
        if txt:
            rows.append({"start": float(s.start), "end": float(s.end), "text": txt})
    return rows

def score_windows(rows, duration, length):
    # Score each candidate window using speech density and attention-grabbing language.
    hooks = re.compile(r"\b(কিন্তু|কারণ|কেন|কীভাবে|অবিশ্বাস্য|সত্যি|ভুল|সমস্যা|সমাধান|জিত|হার|টাকা|রহস্য|তুমি|আপনি|যদি|তাহলে|secret|why|how|but|because|truth|secret|never|amazing|shocking|mistake|money|free|best|worst)\b", re.I)
    starts = []
    t = 0.0
    while t + length <= duration:
        starts.append(t)
        t += max(5, length // 5)
    scored = []
    for start in starts:
        end = start + length
        chosen = [r for r in rows if r["end"] > start and r["start"] < end]
        text = " ".join(r["text"] for r in chosen)
        words = re.findall(r"\w+", text)
        if len(words) < 12:
            continue
        hook_count = len(hooks.findall(text))
        punctuation = text.count("?") + text.count("!") + text.count("।")
        speech_coverage = sum(max(0, min(r["end"], end)-max(r["start"], start)) for r in chosen)
        density = min(len(words) / max(length, 1), 3)
        score = density * 2 + hook_count * 1.5 + punctuation * 0.7 + (speech_coverage / length)
        scored.append((score, start, end, text))
    scored.sort(reverse=True)
    picked = []
    for item in scored:
        _, s, e, _ = item
        if all(e <= p[2] or s >= p[2] for p in picked):
            picked.append(item)
        if len(picked) >= num_clips:
            break
    return sorted(picked, key=lambda x: x[1])

def make_clip(src, start, end, dest, vertical):
    duration = end - start
    if vertical:
        vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    else:
        vf = "scale=1280:-2"
    run(["ffmpeg", "-y", "-ss", str(start), "-i", str(src), "-t", str(duration),
         "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
         "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(dest)])

if st.button("✨ ভাইরাল ক্লিপ তৈরি করুন", type="primary", use_container_width=True):
    if not url.strip():
        st.error("আগে একটি ভিডিও লিংক দিন।")
    elif shutil.which("ffmpeg") is None:
        st.error("FFmpeg ইনস্টল করা নেই। README ফাইলে ইনস্টল করার নিয়ম আছে।")
    else:
        with st.spinner("ভিডিও ডাউনলোড ও বিশ্লেষণ করা হচ্ছে—সময় লাগতে পারে..."):
            try:
                with tempfile.TemporaryDirectory() as tmp:
                    video, title = download_video(url.strip(), tmp)
                    st.write(f"**ভিডিও:** {title}")
                    rows = transcribe(video, model_size)
                    if not rows:
                        st.warning("কথার ট্রান্সক্রিপ্ট পাওয়া যায়নি।")
                    else:
                        probe = run(["ffprobe", "-v", "error", "-show_entries",
                                     "format=duration", "-of", "default=noprint_wrappers=1:nokey=1",
                                     str(video)])
                        duration = float(probe.stdout.strip())
                        picks = score_windows(rows, duration, clip_len)
                        if not picks:
                            st.warning("যথেষ্ট কথাবার্তা পাওয়া যায়নি।")
                        else:
                            outdir = Path("outputs")
                            outdir.mkdir(exist_ok=True)
                            for i, (score, start, end, transcript) in enumerate(picks, 1):
                                dest = outdir / f"viral_clip_{i}.mp4"
                                make_clip(video, start, end, dest, vertical)
                                st.subheader(f"ক্লিপ {i}  |  {int(start)}s–{int(end)}s")
                                st.caption(f"স্বয়ংক্রিয় সম্ভাব্য আকর্ষণ স্কোর: {score:.1f}")
                                st.write(transcript[:700] + ("…" if len(transcript) > 700 else ""))
                                st.video(str(dest))
                                st.download_button(
                                    f"ক্লিপ {i} ডাউনলোড করুন",
                                    data=dest.read_bytes(),
                                    file_name=dest.name,
                                    mime="video/mp4",
                                    key=f"download_{i}"
                                )
                            st.success("ক্লিপ তৈরি হয়েছে! মনে রাখবেন—ভাইরাল হওয়া নিশ্চিত করা যায় না।")
            except Exception as e:
                st.error(f"সমস্যা হয়েছে: {e}")
                st.caption("লিংকটি সমর্থিত কি না, ভিডিওটি পাবলিক কি না, এবং FFmpeg ইনস্টল আছে কি না পরীক্ষা করুন।")
